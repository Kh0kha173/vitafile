import 'dart:async';

abstract class IAuthService {
  Stream<String?> get authStateChanges;
  String? get currentUserId;
  bool get isAuthenticated;

  Future<void> signInWithEmailAndPassword({
    required String email,
    required String password,
  });

  Future<void> registerWithEmailAndPassword({
    required String email,
    required String password,
    required String fullName,
    required String phone,
  });

  Future<void> sendPasswordResetEmail(String email);
  Future<void> signInWithBiometrics();
  Future<void> signOut();
}

class VitaAuthService implements IAuthService {
  // Singleton عشان البيانات تفضل محفوظة في كل شاشات التطبيق
  static final VitaAuthService instance = VitaAuthService._internal();
  factory VitaAuthService() => instance;
  VitaAuthService._internal();

  final _authStateController = StreamController<String?>.broadcast();
  String? _currentUserId;

  // بيانات المستخدم الحالي اللي سجل دخول أو أنشأ حساب
  String currentUserName = '';
  String currentUserEmail = '';
  String currentUserPhone = '';
  String currentUserBloodType = 'Not Set';
  bool isNewAccount = false;

  @override
  Stream<String?> get authStateChanges => _authStateController.stream;

  @override
  String? get currentUserId => _currentUserId;

  @override
  bool get isAuthenticated => _currentUserId != null;

  @override
  Future<void> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    _currentUserId = 'VF-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';
    currentUserEmail = email;
    if (currentUserName.isEmpty) {
      // استخراج الاسم من الإيميل لو سجل دخول مباشرة
      final namePart = email.split('@').first;
      currentUserName = namePart[0].toUpperCase() + namePart.substring(1);
    }
    isNewAccount = false;
    _authStateController.add(_currentUserId);
  }

  @override
  Future<void> registerWithEmailAndPassword({
    required String email,
    required String password,
    required String fullName,
    required String phone,
  }) async {
    _currentUserId = 'VF-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';
    currentUserName = fullName.trim().isNotEmpty ? fullName.trim() : email.split('@').first;
    currentUserEmail = email;
    currentUserPhone = phone;
    isNewAccount = true; // علامة إن ده حساب جديد فاضي بدون بيانات وهمية
    _authStateController.add(_currentUserId);
  }

  @override
  Future<void> sendPasswordResetEmail(String email) async {}

  @override
  Future<void> signInWithBiometrics() async {
    _currentUserId = 'VF-BIO';
    if (currentUserName.isEmpty) currentUserName = 'User';
    _authStateController.add(_currentUserId);
  }

  @override
  Future<void> signOut() async {
    _currentUserId = null;
    currentUserName = '';
    currentUserEmail = '';
    currentUserPhone = '';
    isNewAccount = false;
    _authStateController.add(null);
  }
}