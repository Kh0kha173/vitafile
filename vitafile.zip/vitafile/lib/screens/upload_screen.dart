import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';
import '../models/medical_record.dart';
import '../main.dart';
import '../widgets/vita_app_bar.dart';
import '../widgets/vita_card.dart';
import '../widgets/vita_button.dart';

class UploadScreen extends StatefulWidget {
  const UploadScreen({super.key});

  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _doctorController = TextEditingController();
  final TextEditingController _facilityController = TextEditingController();
  final TextEditingController _notesController = TextEditingController();

  RecordCategory _selectedCategory = RecordCategory.labTest;
  int _selectedSourceIndex = 0;
  String _selectedFileName = '';
  bool _isUploading = false;
  double _uploadProgress = 0.0;

  bool get _isAr => appLocaleNotifier.value.languageCode == 'ar';
  String _tr(String en, String ar) => _isAr ? ar : en;

  String _categoryLabel(RecordCategory cat) {
    switch (cat) {
      case RecordCategory.labTest:
        return _tr('Lab Test', 'تحليل معملي');
      case RecordCategory.imagingXRay:
        return _tr('Imaging & X-Ray', 'أشعة وفحوصات');
      case RecordCategory.prescription:
        return _tr('Prescription', 'روشتة طبية');
      case RecordCategory.doctorNote:
        return _tr('Doctor Note', 'ملاحظة طبيب');
      case RecordCategory.vaccination:
        return _tr('Vaccination', 'تطعيم');
    }
  }

  void _selectSource(int index) {
    setState(() {
      _selectedSourceIndex = index;
      switch (index) {
        case 0:
          _selectedFileName = 'camera_scan.jpg';
          break;
        case 1:
          _selectedFileName = 'gallery_image.jpg';
          break;
        default:
          _selectedFileName = 'document.pdf';
      }
    });
  }

  Future<void> _simulateUpload() async {
    if (_titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_tr('Please enter a document title first.',
              'يرجى إدخال عنوان الملف أولاً.')),
          backgroundColor: AppColors.emergencyRed,
        ),
      );
      return;
    }

    setState(() {
      _isUploading = true;
      _uploadProgress = 0.0;
    });

    for (int i = 1; i <= 10; i++) {
      await Future.delayed(const Duration(milliseconds: 120));
      if (!mounted) return;
      setState(() {
        _uploadProgress = i / 10.0;
      });
    }

    if (!mounted) return;
    setState(() => _isUploading = false);

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            const Icon(Icons.check_circle_rounded,
                color: AppColors.successGreen, size: 26),
            const SizedBox(width: 10),
            Text(
              _tr('Upload Complete', 'تم الرفع بنجاح'),
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
            ),
          ],
        ),
        content: Text(
          _tr(
            'Your medical record has been securely encrypted with 256-bit AES and saved to your VitaFile Health Vault.',
            'تم تشفير ملفك الطبي وحفظه بأمان في خزنتك الصحية على فيتا فايل.',
          ),
          style: const TextStyle(
              fontSize: 13, height: 1.4, color: AppColors.textSecondary),
        ),
        actions: [
          VitaButton(
            label: _tr('Done', 'تم'),
            onPressed: () {
              Navigator.pop(dialogContext);
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }

  InputDecoration _fieldDecoration(String label) {
    return InputDecoration(
      labelText: label,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
    );
  }

  Widget _buildSourceOption(int index, IconData icon, String label) {
    final isSelected = _selectedSourceIndex == index;
    return Expanded(
      child: GestureDetector(
        onTap: _isUploading ? null : () => _selectSource(index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(vertical: 14),
          margin: const EdgeInsets.symmetric(horizontal: 4),
          decoration: BoxDecoration(
            color: isSelected
                ? AppColors.primaryTeal.withOpacity(0.1)
                : AppColors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isSelected ? AppColors.primaryTeal : AppColors.cardBorder,
              width: isSelected ? 2 : 1,
            ),
          ),
          child: Column(
            children: [
              Icon(
                icon,
                size: 24,
                color: isSelected
                    ? AppColors.primaryTeal
                    : AppColors.textSecondary,
              ),
              const SizedBox(height: 6),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected
                      ? AppColors.primaryTeal
                      : AppColors.textSecondary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: VitaAppBar(
        title: _tr('Upload Record', 'رفع ملف طبي'),
        subtitle: _tr('Add a document to your vault', 'أضف ملفاً إلى خزنتك الصحية'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _tr('Source', 'المصدر'),
              style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: AppColors.textPrimary,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                _buildSourceOption(
                    0, Icons.photo_camera_rounded, _tr('Camera', 'الكاميرا')),
                _buildSourceOption(
                    1, Icons.photo_library_rounded, _tr('Gallery', 'المعرض')),
                _buildSourceOption(
                    2, Icons.picture_as_pdf_rounded, _tr('File', 'ملف')),
              ],
            ),
            if (_selectedFileName.isNotEmpty) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  const Icon(Icons.attach_file_rounded,
                      size: 16, color: AppColors.primaryTeal),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      _selectedFileName,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 20),
            VitaCard(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  DropdownButtonFormField<RecordCategory>(
                    value: _selectedCategory,
                    decoration: _fieldDecoration(_tr('Category', 'النوع')),
                    items: RecordCategory.values
                        .map((c) => DropdownMenuItem<RecordCategory>(
                      value: c,
                      child: Text(_categoryLabel(c)),
                    ))
                        .toList(),
                    onChanged: _isUploading
                        ? null
                        : (v) {
                      if (v != null) setState(() => _selectedCategory = v);
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _titleController,
                    enabled: !_isUploading,
                    decoration: _fieldDecoration(
                        _tr('Document Title', 'عنوان الملف')),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _doctorController,
                    enabled: !_isUploading,
                    decoration:
                    _fieldDecoration(_tr('Doctor Name', 'اسم الطبيب')),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _facilityController,
                    enabled: !_isUploading,
                    decoration: _fieldDecoration(
                        _tr('Hospital / Clinic', 'المستشفى أو العيادة')),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _notesController,
                    enabled: !_isUploading,
                    maxLines: 3,
                    decoration: _fieldDecoration(_tr('Notes', 'ملاحظات')),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            if (_isUploading) ...[
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: _uploadProgress,
                  minHeight: 8,
                  color: AppColors.primaryTeal,
                  backgroundColor: AppColors.cardBorder,
                ),
              ),
              const SizedBox(height: 8),
              Center(
                child: Text(
                  '${(_uploadProgress * 100).round()}%',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
              ),
            ] else
              SizedBox(
                width: double.infinity,
                child: VitaButton(
                  label: _tr('Upload to Vault', 'رفع إلى الخزنة'),
                  onPressed: _simulateUpload,
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _titleController.dispose();
    _doctorController.dispose();
    _facilityController.dispose();
    _notesController.dispose();
    super.dispose();
  }
}