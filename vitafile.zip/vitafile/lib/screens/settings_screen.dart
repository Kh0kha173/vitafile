import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';
import '../core/navigation/app_router.dart';
import '../services/auth_service.dart';
import '../main.dart';
import '../widgets/vita_app_bar.dart';
import '../widgets/vita_card.dart';
import '../widgets/vita_badge.dart';

class SettingsScreen extends StatefulWidget {
  final bool isEmbedded;

  const SettingsScreen({super.key, this.isEmbedded = false});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
bool _biometricsEnabled = true;
bool _twoFactorEnabled = true;
bool _medReminders = true;
bool _doctorAlerts = true;
bool _isSyncing = false;

bool get _isAr => appLocaleNotifier.value.languageCode == 'ar';
String _tr(String en, String ar) => _isAr ? ar : en;

String _getInitials(String name) {
final parts = name.trim().split(RegExp(r'\s+'));
if (parts.isEmpty || parts.first.isEmpty) return 'U';
if (parts.length == 1) return parts.first[0].toUpperCase();
return (parts[0][0] + parts[1][0]).toUpperCase();
}

void _triggerManualSync() async {
setState(() => _isSyncing = true);
await Future.delayed(const Duration(milliseconds: 900));
if (!mounted) return;
setState(() => _isSyncing = false);
ScaffoldMessenger.of(context).showSnackBar(
SnackBar(
content: Text(_tr(
'Vault synchronized and encrypted successfully.',
'تمت مزامنة الخزنة وتشفير البيانات بنجاح.',
)),
backgroundColor: AppColors.primaryTeal,
),
);
}

void _handleLogout() {
showDialog(
context: context,
builder: (context) => AlertDialog(
shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
title: Text(
_tr('Lock Vault & Sign Out', 'قفل الخزنة وتسجيل الخروج'),
style: const TextStyle(fontWeight: FontWeight.w700),
),
content: Text(
_tr(
'Your medical records will be encrypted locally and can only be unlocked with your password.',
'سيتم تشفير سجلاتك الطبية محلياً ولن يمكن فتحها إلا بكلمة المرور الخاصة بك.',
),
style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
),
actions: [
TextButton(
onPressed: () => Navigator.pop(context),
child: Text(
_tr('Cancel', 'إلغاء'),
style: const TextStyle(color: AppColors.textSecondary),
),
),
ElevatedButton(
onPressed: () async {
await VitaAuthService.instance.signOut();
if (!mounted) return;
Navigator.pop(context);
Navigator.of(context).pushNamedAndRemoveUntil(AppRoutes.auth, (route) => false);
},
style: ElevatedButton.styleFrom(
backgroundColor: AppColors.emergencyRed,
foregroundColor: AppColors.white,
),
child: Text(_tr('Lock & Sign Out', 'قفل وخروج')),
),
],
),
);
}
@override
Widget build(BuildContext context) {
  final auth = VitaAuthService.instance;
  final fullName = auth.currentUserName.isNotEmpty
      ? auth.currentUserName
      : _tr('New Patient', 'مريض جديد');
  final email = auth.currentUserEmail.isNotEmpty
      ? auth.currentUserEmail
      : 'patient@vitafile.health';
  final initials = _getInitials(fullName);

  return Scaffold(
    backgroundColor: AppColors.background,
    appBar: VitaAppBar(
      title: _tr('Settings & Security', 'الإعدادات والأمان'),
      subtitle: _tr('App Preferences & Compliance', 'تفضيلات التطبيق والخصوصية'),
      showBackButton: !widget.isEmbedded,
    ),
    body: SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          VitaCard(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    gradient: AppColors.tealGradient,
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      initials,
                      style: const TextStyle(
                        color: AppColors.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        fullName,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                      ),
                      Text(
                        email,
                        style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                      ),
                      const SizedBox(height: 4),
                      VitaBadge(
                        label: _tr('VitaFile Pro Vault', 'خزنة فيتا فايل الموثقة'),
                        type: BadgeType.primary,
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: AppColors.textMuted),
                  onPressed: () => Navigator.of(context).pushNamed(AppRoutes.profile),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          _buildSectionHeader(_tr('Language & Display', 'اللغة والعرض')),
          const SizedBox(height: 10),
          VitaCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.language_rounded, color: AppColors.primaryTeal),
              title: Text(
                _tr('App Language', 'لغة التطبيق'),
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
              ),
              subtitle: Text(
                _isAr ? 'العربية' : 'English',
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
              ),
              trailing: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryTealSoft,
                  foregroundColor: AppColors.primaryTealDark,
                  elevation: 0,
                ),
                onPressed: () {
                  appLocaleNotifier.value = _isAr ? const Locale('en') : const Locale('ar');
                  setState(() {});
                },
                child: Text(
                  _isAr ? 'Switch to English' : 'تغيير للعربية',
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),

          _buildSectionHeader(_tr('Cloud Sync & Backup', 'المزامنة والنسخ الاحتياطي')),
          const SizedBox(height: 10),
          VitaCard(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.cloud_done_rounded, color: AppColors.primaryTeal, size: 22),
                        const SizedBox(width: 10),
                        Text(
                          _tr('Encrypted Cloud Vault', 'الخزنة السحابية المشفرة'),
                          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                    VitaBadge(label: _tr('Synced', 'متزامن'), type: BadgeType.success),
                  ],
                ),
                const Divider(height: 20, color: AppColors.cardBorderSubtle),
                InkWell(
                  onTap: _isSyncing ? null : _triggerManualSync,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (_isSyncing)
                        const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.primaryTeal),
                        )
                      else
                        const Icon(Icons.sync_rounded, color: AppColors.primaryTeal, size: 18),
                      const SizedBox(width: 8),
                      Text(
                        _isSyncing
                            ? _tr('Synchronizing...', 'جاري المزامنة...')
                            : _tr('Sync Vault Now', 'مزامنة الخزنة الآن'),
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: AppColors.primaryTeal,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          _buildSectionHeader(_tr('Security & Biometrics', 'الأمان والبصمة')),
          const SizedBox(height: 10),
          VitaCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Column(
              children: [
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    _tr('Biometric Authentication', 'الدخول بالبصمة / الوجه'),
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                  subtitle: Text(
                    _tr('Require Face ID / Fingerprint to open app', 'طلب البصمة عند فتح التطبيق'),
                    style: const TextStyle(fontSize: 11, color: AppColors.textSecondary),
                  ),
                  value: _biometricsEnabled,
                  activeColor: AppColors.primaryTeal,
                  onChanged: (v) => setState(() => _biometricsEnabled = v),
                ),
                const Divider(height: 1, color: AppColors.cardBorderSubtle),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    _tr('Two-Factor Authentication (2FA)', 'المصادقة الثنائية'),
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                  value: _twoFactorEnabled,
                  activeColor: AppColors.primaryTeal,
                  onChanged: (v) => setState(() => _twoFactorEnabled = v),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          _buildSectionHeader(_tr('Notifications & Alarms', 'الإشعارات والتنبيهات')),
          const SizedBox(height: 10),
          VitaCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            child: Column(
              children: [
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    _tr('Medication Schedule Reminders', 'تذكير مواعيد الأدوية'),
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                  value: _medReminders,
                  activeColor: AppColors.primaryTeal,
                  onChanged: (v) => setState(() => _medReminders = v),
                ),
                const Divider(height: 1, color: AppColors.cardBorderSubtle),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    _tr('Doctor Access Expiration Alerts', 'تنبيه انتهاء صلاحية دخول الطبيب'),
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                  value: _doctorAlerts,
                  activeColor: AppColors.primaryTeal,
                  onChanged: (v) => setState(() => _doctorAlerts = v),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          VitaCard(
            onTap: _handleLogout,
            padding: const EdgeInsets.symmetric(vertical: 14),
            borderColor: AppColors.emergencyRed.withOpacity(0.3),
            backgroundColor: AppColors.emergencyRedSoft.withOpacity(0.3),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.logout_rounded, color: AppColors.emergencyRed, size: 20),
                const SizedBox(width: 8),
                Text(
                  _tr('Lock Vault & Sign Out', 'قفل الخزنة وتسجيل الخروج'),
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: AppColors.emergencyRed,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          Center(
            child: Column(
              children: [
                const Text(
                  'VitaFile Mobile v2.4.0 (Build 2026.11)',
                  style: TextStyle(fontSize: 11, color: AppColors.textMuted, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 2),
                Text(
                  _tr(
                    'End-to-End Encrypted Personal Health Record System',
                    'نظام سجلات صحية شخصية مشفر بالكامل',
                  ),
                  style: const TextStyle(fontSize: 10, color: AppColors.textMuted),
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
        ],
      ),
    ),
  );
}

Widget _buildSectionHeader(String title) {
  return Text(
    title,
    style: const TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.w700,
      color: AppColors.textPrimary,
    ),
  );
}
}