import 'package:flutter/material.dart';
import '../core/constants/app_colors.dart';
import '../core/navigation/app_router.dart';
import '../models/medical_record.dart';
import '../main.dart';
import '../widgets/vita_app_bar.dart';
import '../widgets/vita_card.dart';
import '../widgets/vita_badge.dart';
import '../widgets/vita_button.dart';

class RecordsScreen extends StatefulWidget {
  final bool isEmbedded;

  const RecordsScreen({super.key, this.isEmbedded = false});

  @override
  State<RecordsScreen> createState() => _RecordsScreenState();
}

class _RecordsScreenState extends State<RecordsScreen> {
int _selectedCategoryIndex = 0;
String _searchQuery = '';
final TextEditingController _searchController = TextEditingController();
final List _records = [];

bool get _isAr => appLocaleNotifier.value.languageCode == 'ar';
String _tr(String en, String ar) => _isAr ? ar : en;

List get _categories => [
_tr('All', 'الكل'),
_tr('Lab Tests', 'تحاليل معملية'),
_tr('Imaging & X-Rays', 'أشعة وفحوصات'),
_tr('Prescriptions', 'روشتات'),
_tr('Doctor Notes', 'ملاحظات الطبيب'),
_tr('Vaccines', 'تطعيمات'),
];

List get _filteredRecords {
return _records.where((item) {
final MedicalRecord record = item;
final matchesSearch = record.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
record.doctorName.toLowerCase().contains(_searchQuery.toLowerCase()) ||
record.facility.toLowerCase().contains(_searchQuery.toLowerCase());

if (!matchesSearch) return false;

if (_selectedCategoryIndex == 0) return true;
if (_selectedCategoryIndex == 1) return record.category == RecordCategory.labTest;
if (_selectedCategoryIndex == 2) return record.category == RecordCategory.imagingXRay;
if (_selectedCategoryIndex == 3) return record.category == RecordCategory.prescription;
if (_selectedCategoryIndex == 4) return record.category == RecordCategory.doctorNote;
if (_selectedCategoryIndex == 5) return record.category == RecordCategory.vaccination;

return true;
}).toList();
}

void _showRecordDetailSheet(MedicalRecord record) {
showModalBottomSheet(
context: context,
isScrollControlled: true,
backgroundColor: Colors.transparent,
builder: (context) => DraggableScrollableSheet(
initialChildSize: 0.78,
minChildSize: 0.5,
maxChildSize: 0.95,
builder: (_, scrollController) => Container(
decoration: const BoxDecoration(
color: AppColors.white,
borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
),
child: Column(
children: [
const SizedBox(height: 12),
Center(
child: Container(
width: 44,
height: 5,
decoration: BoxDecoration(
color: AppColors.cardBorder,
borderRadius: BorderRadius.circular(10),
),
),
),
Expanded(
child: ListView(
controller: scrollController,
padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
children: [
Row(
mainAxisAlignment: MainAxisAlignment.spaceBetween,
children: [
VitaBadge(
label: record.category.displayName,
type: BadgeType.medical,
),
if (record.isVerified)
VitaBadge(
label: _tr('Clinician Verified', 'موثق طبياً'),
type: BadgeType.success,
icon: Icons.verified_rounded,
),
],
),
const SizedBox(height: 12),
Text(
record.title,
style: const TextStyle(
fontSize: 20,
fontWeight: FontWeight.w800,
color: AppColors.textPrimary,
),
),
const SizedBox(height: 6),
Text(
'${record.facility} • ${record.date}',
style: const TextStyle(
fontSize: 13,
color: AppColors.textSecondary,
),
),
const SizedBox(height: 4),
Text(
'${_tr("Ordering Physician", "الطبيب المعالج")}: ${record.doctorName}',
style: const TextStyle(
fontSize: 12,
fontWeight: FontWeight.w600,
color: AppColors.primaryTeal,
),
),
const Divider(height: 28, color: AppColors.cardBorderSubtle),
Text(
_tr('Clinical Summary', 'الملخص الطبي'),
style: const TextStyle(
fontSize: 15,
fontWeight: FontWeight.w700,
color: AppColors.textPrimary,
),
),
const SizedBox(height: 6),
Text(
record.summary,
style: const TextStyle(
fontSize: 13,
height: 1.4,
color: AppColors.textSecondary,
),
),
const SizedBox(height: 16),
Text(
_tr('Detailed Diagnostic Findings', 'نتائج التشخيص التفصيلية'),
style: const TextStyle(
fontSize: 15,
fontWeight: FontWeight.w700,
color: AppColors.textPrimary,
),
),
const SizedBox(height: 6),
Text(
record.detailedNotes,
style: const TextStyle(
fontSize: 13,
height: 1.4,
color: AppColors.textSecondary,
),
),
if (record.biomarkers.isNotEmpty) ...[
const SizedBox(height: 20),
Text(
_tr('Biomarker Panel Breakdown', 'تفاصيل المؤشرات الحيوية'),
style: const TextStyle(
fontSize: 15,
fontWeight: FontWeight.w700,
color: AppColors.textPrimary,
),
),
const SizedBox(height: 10),
...record.biomarkers.map((b) => _buildBiomarkerRow(b)),
],
const SizedBox(height: 24),
VitaCard(
padding: const EdgeInsets.all(12),
backgroundColor: AppColors.background,
child: Row(
children: [
const Icon(Icons.picture_as_pdf_rounded, color: AppColors.emergencyRed, size: 30),
const SizedBox(width: 12),
Expanded(
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Text(
record.fileName,
style: const TextStyle(
fontSize: 13,
fontWeight: FontWeight.w700,
color: AppColors.textPrimary,
),
maxLines: 1,
overflow: TextOverflow.ellipsis,
),
Text(
'${_tr("Size", "الحجم")}: ${record.fileSize} • ${_tr("Encrypted PDF", "ملف مشفر")}',
style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
),
],
),
),
IconButton(
icon: const Icon(Icons.download_rounded, color: AppColors.primaryTeal),
onPressed: () {
Navigator.pop(context);
ScaffoldMessenger.of(context).showSnackBar(
SnackBar(
content: Text(_tr(
'Downloaded ${record.fileName} to local secure storage.',
'تم تحميل ${record.fileName} إلى التخزين الآمن.',
)),
backgroundColor: AppColors.primaryTeal,
),
);
},
),
],
),
),
const SizedBox(height: 20),
VitaButton(
label: _tr('Share with Doctor', 'مشاركة مع الطبيب'),
icon: Icons.key_rounded,
onPressed: () {
Navigator.pop(context);
Navigator.of(context).pushNamed(AppRoutes.doctorAccess);
},
),
const SizedBox(height: 16),
],
),
),
],
),
),
),
);
}
Widget _buildBiomarkerRow(BiomarkerResult b) {
  return Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.cardBorderSubtle),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                b.name,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textPrimary,
                ),
              ),
              Text(
                '${_tr("Ref", "المرجع")}: ${b.referenceRange} ${b.unit}',
                style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
              ),
            ],
          ),
          Row(
            children: [
              Text(
                '${b.value} ${b.unit}',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: AppColors.primaryTeal,
                ),
              ),
              const SizedBox(width: 6),
              const Icon(Icons.check_circle_rounded, size: 16, color: AppColors.successGreen),
            ],
          ),
        ],
      ),
    ),
  );
}

@override
void dispose() {
  _searchController.dispose();
  super.dispose();
}

@override
Widget build(BuildContext context) {
  final cats = _categories;
  final filtered = _filteredRecords;

  return Scaffold(
    backgroundColor: AppColors.background,
    appBar: VitaAppBar(
      title: _tr('Medical Records', 'السجلات الطبية'),
      subtitle: '${filtered.length} ${_tr("Verified Documents", "ملفات موثقة")}',
      showBackButton: !widget.isEmbedded,
      actions: [
        IconButton(
          icon: const Icon(Icons.add_circle_outline_rounded, color: AppColors.primaryTeal, size: 24),
          onPressed: () => Navigator.of(context).pushNamed(AppRoutes.upload),
        ),
      ],
    ),
    body: Column(
      children: [
        Container(
          color: AppColors.white,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          child: Column(
            children: [
              TextField(
                controller: _searchController,
                onChanged: (v) => setState(() => _searchQuery = v),
                decoration: InputDecoration(
                  hintText: _tr('Search tests, doctors, hospitals...', 'ابحث في التحاليل، الأطباء، المستشفيات...'),
                  prefixIcon: const Icon(Icons.search_rounded, size: 20, color: AppColors.textMuted),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? IconButton(
                    icon: const Icon(Icons.clear_rounded, size: 18),
                    onPressed: () {
                      _searchController.clear();
                      setState(() => _searchQuery = '');
                    },
                  )
                      : null,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 34,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: cats.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, index) {
                    final cat = cats[index];
                    final isSelected = _selectedCategoryIndex == index;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedCategoryIndex = index),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(
                          color: isSelected ? AppColors.primaryTeal : AppColors.background,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isSelected ? AppColors.primaryTeal : AppColors.cardBorder,
                          ),
                        ),
                        child: Center(
                          child: Text(
                            cat,
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                              color: isSelected ? AppColors.white : AppColors.textSecondary,
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: filtered.isEmpty
              ? Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.folder_off_outlined, size: 48, color: AppColors.textMuted),
                const SizedBox(height: 12),
                Text(
                  _tr('No medical records yet', 'لا توجد سجلات طبية مضافة بعد'),
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: AppColors.textSecondary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  _tr('Tap Upload Record below to add your first file', 'اضغط على رفع سجل بالأسفل لإضافة أول ملف'),
                  style: const TextStyle(fontSize: 12, color: AppColors.textMuted),
                ),
              ],
            ),
          )
              : ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            itemCount: filtered.length,
            itemBuilder: (context, index) {
              final MedicalRecord record = filtered[index];
              return _buildRecordCard(record);
            },
          ),
        ),
      ],
    ),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: () => Navigator.of(context).pushNamed(AppRoutes.upload),
      backgroundColor: AppColors.primaryTeal,
      foregroundColor: AppColors.white,
      icon: const Icon(Icons.cloud_upload_rounded),
      label: Text(
        _tr('Upload Record', 'رفع سجل'),
        style: const TextStyle(fontWeight: FontWeight.w700),
      ),
    ),
  );
}

Widget _buildRecordCard(MedicalRecord record) {
  IconData icon;
  Color iconColor;

  switch (record.category) {
    case RecordCategory.labTest:
      icon = Icons.biotech_rounded;
      iconColor = AppColors.primaryTeal;
      break;
    case RecordCategory.imagingXRay:
      icon = Icons.document_scanner_rounded;
      iconColor = AppColors.medicalBlue;
      break;
    case RecordCategory.prescription:
      icon = Icons.medication_rounded;
      iconColor = AppColors.warningOrange;
      break;
    case RecordCategory.doctorNote:
      icon = Icons.note_alt_rounded;
      iconColor = AppColors.infoPurple;
      break;
    case RecordCategory.vaccination:
      icon = Icons.vaccines_rounded;
      iconColor = AppColors.successGreen;
      break;
  }

  return Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: VitaCard(
      onTap: () => _showRecordDetailSheet(record),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: iconColor, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        VitaBadge(
                          label: record.category.displayName,
                          type: BadgeType.neutral,
                        ),
                        Text(
                          record.date,
                          style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      record.title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '${record.facility} • ${record.doctorName}',
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            record.summary,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 12,
              color: AppColors.textSecondary,
              height: 1.35,
            ),
          ),
          const Divider(height: 18, color: AppColors.cardBorderSubtle),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  const Icon(Icons.attachment_rounded, size: 14, color: AppColors.textMuted),
                  const SizedBox(width: 4),
                  Text(
                    record.fileSize,
                    style: const TextStyle(fontSize: 11, color: AppColors.textMuted, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              Row(
                children: [
                  Text(
                    _tr('View Details', 'عرض التفاصيل'),
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: AppColors.primaryTeal,
                    ),
                  ),
                  const SizedBox(width: 2),
                  const Icon(Icons.chevron_right_rounded, size: 16, color: AppColors.primaryTeal),
                ],
              ),
            ],
          ),
        ],
      ),
    ),
  );
}
}